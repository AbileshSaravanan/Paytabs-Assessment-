package com.poc;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/transaction")
public class System1Controller {

    @PostMapping
    public Object route(@RequestBody TxnRequest req){
        if(req.cardNumber==null || req.pin==null || req.type==null || req.amount<=0)
            return new TxnResponse("Invalid request", false, 0);

        if(!req.type.equals("withdraw") && !req.type.equals("topup"))
            return new TxnResponse("Invalid type", false, 0);

        if(!req.cardNumber.startsWith("4"))
            return new TxnResponse("Card range not supported", false, 0);

        RestTemplate rt=new RestTemplate();
        return rt.postForObject("http://localhost:8080/process", req, Object.class);
    }
}
