package com.poc;
public class Card {
    public String cardNumber;
    public String pinHash;
    public double balance;

    public Card(String c,String p,double b){
        cardNumber=c; pinHash=p; balance=b;
    }
}
