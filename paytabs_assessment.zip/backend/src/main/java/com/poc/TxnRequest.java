package com.poc;
public class TxnRequest {
    public String cardNumber;
    public String pin;
    public double amount;
    public String type;
}
