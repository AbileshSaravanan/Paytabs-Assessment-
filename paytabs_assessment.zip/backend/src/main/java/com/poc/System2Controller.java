package com.poc;
import org.springframework.web.bind.annotation.*;
import java.security.MessageDigest;

@RestController
@RequestMapping("/process")
public class System2Controller {

    @PostMapping
    public Object process(@RequestBody TxnRequest req){
        if(!CardDB.cards.containsKey(req.cardNumber))
            return new TxnResponse("Invalid card", false, 0);

        Card c = CardDB.cards.get(req.cardNumber);
        String hashed = sha(req.pin);

        if(!hashed.equals(c.pinHash))
            return new TxnResponse("Invalid PIN", false, 0);

        if(req.type.equals("withdraw")){
            if(c.balance < req.amount)
                return new TxnResponse("Insufficient balance", false, c.balance);
            c.balance -= req.amount;
        } else {
            c.balance += req.amount;
        }

        return new TxnResponse("Success", true, c.balance);
    }

    private String sha(String s){
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b=md.digest(s.getBytes());
            StringBuilder sb=new StringBuilder();
            for(byte x:b) sb.append(String.format("%02x",x));
            return sb.toString();
        }catch(Exception e){ return ""; }
    }
}
