package com.poc;
public class TxnResponse {
    public String message;
    public boolean success;
    public double balance;

    public TxnResponse(String m, boolean s, double b){
        message=m; success=s; balance=b;
    }
}
