Run: npx create-react-app ui
